GAIA CryoVirgin · v5.1 · Accounts · Database Core
=================================================

Week 2: Mon Feb 8, 2027 → Sun Feb 14, 2027

This package adds the **SQL schema** for the multi-company Accounts brain:
sales, staff, customers, services, products, payroll, and receivables.

What you get
------------

- db/sql/accounts_core_v5_1_week2.sql
  - Postgres SQL script (works on Supabase or any Postgres).
  - Tables:
    - companies
    - branches
    - staff
    - customers
    - services
    - products
    - sales
    - sale_items
    - payments
    - staff_commissions
    - payroll_periods
    - payroll_entries
    - receivables
  - All business tables have a **company_id** column so data is segregated.
  - Includes enums for:
    - staff_role
    - bill_type
    - payment_channel
    - sale_item_type
  - Includes a generic updated_at trigger for key tables.

How to use this (later, when you are ready)
-------------------------------------------

1. Create a Postgres database (e.g. Supabase project).
2. Open the SQL editor for that DB.
3. Paste the contents of:

   db/sql/accounts_core_v5_1_week2.sql

   and run it once.

4. This will create the required tables in that database.

5. Later, GAIA CryoVirgin will connect to this DB using a connection string
   (DATABASE_URL), and the Accounts UI will filter everything by:

   - company_id (for each table)
   - the selected company in /accounts.

Notes
-----

- This does NOT yet wire GAIA's frontend to the database. It is the **schema only**.
- You can safely keep this file in your repo under db/sql and only run it when
  you're ready to actually use Supabase/Postgres.
- The current /accounts page (with Mikoshi + Call Center Python) still works
  exactly as before, independent of these tables.

Next steps (future weeks)
-------------------------

- Add a Company API in GAIA that:
  - Reads companies from this DB.
  - Creates a new company row when you click "Add new company".
- Add import scripts to feed:
  - Mikoshi sales reports into the `sales`, `sale_items`, `payments` tables.
- Connect staff/commissions/salaries to your real rules.

For now, this week is purely about **structuring the whole company** in SQL so
that any GAIA deployment (local or Vercel) can share the same online database.
