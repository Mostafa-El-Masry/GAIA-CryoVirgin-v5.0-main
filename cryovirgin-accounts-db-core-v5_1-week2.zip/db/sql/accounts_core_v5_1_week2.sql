-- GAIA CryoVirgin v5.1 · Accounts · Multi-company Core Schema
-- Week 2: Mon Feb 8, 2027 → Sun Feb 14, 2027
-- Target: Postgres (e.g. Supabase) – but can run on any PostgreSQL server.

-- IMPORTANT:
--  - All business tables are scoped by company_id.
--  - This schema does NOT include call center or BRS yet; those can be added later.
--  - Run this once in your remote Postgres (e.g. Supabase SQL Editor) when you're ready.

-- Safety: create a dedicated schema for GAIA if you like
-- CREATE SCHEMA IF NOT EXISTS gaia;
-- SET search_path TO gaia, public;

------------------------------------------------------------
-- 1. Companies
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS companies (
    id              BIGSERIAL PRIMARY KEY,
    name            TEXT NOT NULL,
    slug            TEXT NOT NULL UNIQUE,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_companies_slug ON companies(slug);

------------------------------------------------------------
-- 2. Branches (per company)
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS branches (
    id              BIGSERIAL PRIMARY KEY,
    company_id      BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    code            TEXT,
    name            TEXT NOT NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, name)
);

CREATE INDEX IF NOT EXISTS idx_branches_company ON branches(company_id);
CREATE INDEX IF NOT EXISTS idx_branches_company_code ON branches(company_id, code);

------------------------------------------------------------
-- 3. Staff (employees)
------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'staff_role') THEN
    CREATE TYPE staff_role AS ENUM (
        'ACCOUNTANT',
        'CALL_CENTER',
        'RECEPTIONIST',
        'THERAPIST',
        'DOCTOR',
        'MANAGER',
        'OTHER'
    );
  END IF;
END$$;

CREATE TABLE IF NOT EXISTS staff (
    id              BIGSERIAL PRIMARY KEY,
    company_id      BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    branch_id       BIGINT REFERENCES branches(id) ON DELETE SET NULL,
    full_name       TEXT NOT NULL,
    role            staff_role NOT NULL DEFAULT 'OTHER',
    email           TEXT,
    phone           TEXT,
    hire_date       DATE,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    base_salary     NUMERIC(12,3),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_staff_company ON staff(company_id);
CREATE INDEX IF NOT EXISTS idx_staff_company_branch ON staff(company_id, branch_id);

------------------------------------------------------------
-- 4. Customers
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS customers (
    id              BIGSERIAL PRIMARY KEY,
    company_id      BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    full_name       TEXT,
    phone           TEXT,
    email           TEXT,
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, phone)
);

CREATE INDEX IF NOT EXISTS idx_customers_company ON customers(company_id);
CREATE INDEX IF NOT EXISTS idx_customers_company_phone ON customers(company_id, phone);

------------------------------------------------------------
-- 5. Services
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS services (
    id              BIGSERIAL PRIMARY KEY,
    company_id      BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    code            TEXT,
    name            TEXT NOT NULL,
    description     TEXT,
    default_price   NUMERIC(12,3),
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, name)
);

CREATE INDEX IF NOT EXISTS idx_services_company ON services(company_id);
CREATE INDEX IF NOT EXISTS idx_services_company_code ON services(company_id, code);

------------------------------------------------------------
-- 6. Products
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
    id              BIGSERIAL PRIMARY KEY,
    company_id      BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    sku             TEXT,
    name            TEXT NOT NULL,
    description     TEXT,
    default_price   NUMERIC(12,3),
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, name)
);

CREATE INDEX IF NOT EXISTS idx_products_company ON products(company_id);
CREATE INDEX IF NOT EXISTS idx_products_company_sku ON products(company_id, sku);

------------------------------------------------------------
-- 7. Sales (bills / invoices)
------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'bill_type') THEN
    CREATE TYPE bill_type AS ENUM (
        'APPOINTMENT',
        'ONLINE',
        'QUICK_SALE'
    );
  END IF;
END$$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'payment_channel') THEN
    CREATE TYPE payment_channel AS ENUM (
        'CASH',
        'KNET',
        'VISA',
        'MASTER',
        'ONLINE',
        'WALLET',
        'BANK_TRANSFER',
        'OTHER'
    );
  END IF;
END$$;

CREATE TABLE IF NOT EXISTS sales (
    id                  BIGSERIAL PRIMARY KEY,
    company_id          BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    branch_id           BIGINT REFERENCES branches(id) ON DELETE SET NULL,
    customer_id         BIGINT REFERENCES customers(id) ON DELETE SET NULL,
    staff_id            BIGINT REFERENCES staff(id) ON DELETE SET NULL,
    bill_type           bill_type NOT NULL,
    bill_no             BIGINT NOT NULL,
    bill_system_id      BIGINT,
    bill_date           DATE NOT NULL,
    net_amount          NUMERIC(14,3) NOT NULL DEFAULT 0,
    total_discount      NUMERIC(14,3) NOT NULL DEFAULT 0,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, bill_type, bill_no, bill_date)
);

CREATE INDEX IF NOT EXISTS idx_sales_company ON sales(company_id);
CREATE INDEX IF NOT EXISTS idx_sales_company_branch ON sales(company_id, branch_id);
CREATE INDEX IF NOT EXISTS idx_sales_company_customer ON sales(company_id, customer_id);
CREATE INDEX IF NOT EXISTS idx_sales_company_bill ON sales(company_id, bill_type, bill_no);

------------------------------------------------------------
-- 8. Sale items
------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'sale_item_type') THEN
    CREATE TYPE sale_item_type AS ENUM (
        'SERVICE',
        'PRODUCT'
    );
  END IF;
END$$;

CREATE TABLE IF NOT EXISTS sale_items (
    id                  BIGSERIAL PRIMARY KEY,
    company_id          BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    sale_id             BIGINT NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    item_type           sale_item_type NOT NULL,
    service_id          BIGINT REFERENCES services(id) ON DELETE SET NULL,
    product_id          BIGINT REFERENCES products(id) ON DELETE SET NULL,
    quantity            NUMERIC(12,3) NOT NULL DEFAULT 1,
    unit_price          NUMERIC(14,3) NOT NULL DEFAULT 0,
    line_discount       NUMERIC(14,3) NOT NULL DEFAULT 0,
    line_total          NUMERIC(14,3) NOT NULL DEFAULT 0,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sale_items_company ON sale_items(company_id);
CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id);

------------------------------------------------------------
-- 9. Payments
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
    id                  BIGSERIAL PRIMARY KEY,
    company_id          BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    sale_id             BIGINT NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    channel             payment_channel NOT NULL,
    amount              NUMERIC(14,3) NOT NULL DEFAULT 0,
    reference           TEXT,
    received_date       DATE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_payments_company ON payments(company_id);
CREATE INDEX IF NOT EXISTS idx_payments_company_channel ON payments(company_id, channel);

------------------------------------------------------------
-- 10. Staff commissions
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS staff_commissions (
    id                  BIGSERIAL PRIMARY KEY,
    company_id          BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    staff_id            BIGINT NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
    sale_id             BIGINT NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    sale_item_id        BIGINT REFERENCES sale_items(id) ON DELETE SET NULL,
    commission_base     NUMERIC(14,3) NOT NULL DEFAULT 0,
    commission_rate     NUMERIC(7,4) NOT NULL DEFAULT 0,
    commission_amount   NUMERIC(14,3) NOT NULL DEFAULT 0,
    period_month        SMALLINT,
    period_year         SMALLINT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_staff_commissions_company ON staff_commissions(company_id);
CREATE INDEX IF NOT EXISTS idx_staff_commissions_staff ON staff_commissions(company_id, staff_id);

------------------------------------------------------------
-- 11. Payroll
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payroll_periods (
    id                  BIGSERIAL PRIMARY KEY,
    company_id          BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name                TEXT NOT NULL,
    start_date          DATE NOT NULL,
    end_date            DATE NOT NULL,
    is_closed           BOOLEAN NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, start_date, end_date)
);

CREATE TABLE IF NOT EXISTS payroll_entries (
    id                  BIGSERIAL PRIMARY KEY,
    company_id          BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    payroll_period_id   BIGINT NOT NULL REFERENCES payroll_periods(id) ON DELETE CASCADE,
    staff_id            BIGINT NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
    base_salary         NUMERIC(14,3) NOT NULL DEFAULT 0,
    commission_total    NUMERIC(14,3) NOT NULL DEFAULT 0,
    bonus               NUMERIC(14,3) NOT NULL DEFAULT 0,
    deductions          NUMERIC(14,3) NOT NULL DEFAULT 0,
    net_pay             NUMERIC(14,3) NOT NULL DEFAULT 0,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, payroll_period_id, staff_id)
);

CREATE INDEX IF NOT EXISTS idx_payroll_entries_company ON payroll_entries(company_id);

------------------------------------------------------------
-- 12. Receivables (customer dues)
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS receivables (
    id                  BIGSERIAL PRIMARY KEY,
    company_id          BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    sale_id             BIGINT NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    customer_id         BIGINT REFERENCES customers(id) ON DELETE SET NULL,
    original_amount     NUMERIC(14,3) NOT NULL DEFAULT 0,
    outstanding_amount  NUMERIC(14,3) NOT NULL DEFAULT 0,
    due_date            DATE,
    status              TEXT NOT NULL DEFAULT 'OPEN',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, sale_id)
);

CREATE INDEX IF NOT EXISTS idx_receivables_company ON receivables(company_id);
CREATE INDEX IF NOT EXISTS idx_receivables_company_status ON receivables(company_id, status);

------------------------------------------------------------
-- 13. updated_at trigger
------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE
  rec RECORD;
BEGIN
  FOR rec IN
    SELECT tablename
    FROM pg_tables
    WHERE schemaname = 'public'
      AND tablename IN (
        'companies','branches','staff','customers','services','products',
        'sales','sale_items','payments','staff_commissions',
        'payroll_periods','payroll_entries','receivables'
      )
  LOOP
    EXECUTE format($f$
      DO $$BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_trigger WHERE tgname = 'trg_%1$s_updated_at'
        ) THEN
          CREATE TRIGGER trg_%1$s_updated_at
          BEFORE UPDATE ON %1$s
          FOR EACH ROW EXECUTE FUNCTION set_updated_at();
        END IF;
      END$$;
    $f$, rec.tablename);
  END LOOP;
END$$;
